package com.gemini.api;

import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ApiApplication {

	public static void main(String[] args) throws Exception {
		int nonce = 1620728226;//(int) (new Date().getTime()/1000);
    	GeminiNewBrokerorderRequest gmbr = new GeminiNewBrokerorderRequest("/v1/clearing/broker/new", nonce, "R485E04Q","Z4929ZDY",
    			"ethusd", "175.00", 1.0, "200","sell");
    	ObjectMapper om = new ObjectMapper();
    	String requestBodyString = om.writerWithDefaultPrettyPrinter().writeValueAsString(gmbr);
    	System.out.println("###### requestBodyString "+requestBodyString);
    	String encodedPayloadString = Base64.getEncoder().encodeToString(requestBodyString.getBytes());
    	//String encodedHexString = Hex.encodeHexString(requestBodyString.getBytes());
    	System.out.println("###### encodedPayloadString "+encodedPayloadString);

    	String api_key = "account-EP1eYoOzEmWPTPnd4Qrk";
    	String api_secret = "43SoBBdTE4VSUmFHrAMJwg5cyipw";
    	Mac mac = HmacUtils.getHmacSha384(api_secret.getBytes());
    	byte[] HmachSha256DigestBytes = mac.doFinal();
    	String signatureString = Base64.getEncoder().encodeToString(HmachSha256DigestBytes);
    	//String signatureString = Hex.encodeHexString(HmachSha256DigestBytes);
    	System.out.println("###### signatureString "+signatureString);
    	
    	RestTemplate rt = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
    	headers.add("Content-Type", "text/plain");
    	headers.add("Content-Length", "0");
    	headers.add("X-GEMINI-APIKEY", api_key);
    	headers.add("X-GEMINI-PAYLOAD", encodedPayloadString);
    	headers.add("X-GEMINI-SIGNATURE", signatureString);
    	headers.add("Cache-Control", "no-cache");
    	
    	String sig = getSignature(api_secret, requestBodyString);
    	System.out.println("##### sig "+sig);
    	
    	String sig1 = GenerateSignature(Base64.getEncoder().encodeToString(api_secret.getBytes()), requestBodyString);
    	System.out.println("##### sig1 "+sig1);

    	HttpEntity<GeminiNewBrokerorderRequest> requestEntity = new HttpEntity<>(headers);
    	String response = rt.exchange("https://api.sandbox.gemini.com/v1/clearing/broker/new", HttpMethod.POST, requestEntity, String.class).getBody();
    	////HmacUtils.hmacSha384(api_secret, "valueToDigest");
    	System.out.println("### response "+response);

	}
    private static String getSignature(String api_secret, String resource) throws Exception {
    	// Get an HMAC-SHA1 signing key from the raw key bytes
    	String key = Base64.getEncoder().encodeToString(api_secret.getBytes());
        SecretKeySpec sha1Key = new SecretKeySpec(key.getBytes(), "HmacSHA1");

        // Get an HMAC-SHA1 Mac instance and initialize it with the HMAC-SHA1 key
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(sha1Key);

        // compute the binary signature for the request
        byte[] sigBytes = mac.doFinal(resource.getBytes());

        // base 64 encode the binary signature
        // Base64 is JDK 1.8 only - older versions may need to use Apache Commons or similar.
        String signature = Base64.getEncoder().encodeToString(sigBytes);
        
        // convert the signature to 'web safe' base 64
        signature = signature.replace('+', '-');
        signature = signature.replace('/', '_');
        return signature;
    }
    private static String GenerateSignature(String keyString, String payloadString) throws Exception {
    	byte[] decodedKey = Base64.getDecoder().decode(keyString);
    	//String decodedKeyString = new String(decodedKey);
    	SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "HmacSHA384");
    	Mac hmacSha384 = Mac.getInstance("HmacSHA384");
    	hmacSha384.init(originalKey);
    	//hmacSha384.update(signatureParams.getBytes());
    	byte[] HmachSha384DigestBytes = hmacSha384.doFinal(payloadString.getBytes());
    	//return Base64.getEncoder().encodeToString(HmachSha384DigestBytes);
    	return bytesToHex(HmachSha384DigestBytes);
    }
    private static String bytesToHex(final byte[] hash) {
        final StringBuffer hexString = new StringBuffer();
        for (int i = 0; i < hash.length; i++) {
            final String hex = Integer.toHexString(0xff & hash[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

}
