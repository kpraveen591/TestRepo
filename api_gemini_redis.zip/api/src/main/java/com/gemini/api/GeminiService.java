package com.gemini.api;

import java.util.Base64;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.digest.HmacAlgorithms;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class GeminiService {
	
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	private HashOperations<String, String, String> hashOperations;

	@PostConstruct
	private void init() {
	    hashOperations = stringRedisTemplate.opsForHash();
	}

	private String api_key = "account-EP1eYoOzEmWPTPnd4Qrk";
	private String api_secret = "43SoBBdTE4VSUmFHrAMJwg5cyipw";

	private final String COUNT = "count";

	public String createNewBroker() {

		if (!isRequestAllowed("gemini:"+api_key)) {
			return "Rate Limit Reached. Request not processed.";
		}
		String response = "";
		try {
			int nonce = (int) (new Date().getTime()/1000);
			Random random = new Random(); 
	    	GeminiNewBrokerorderRequest gmbr = new GeminiNewBrokerorderRequest("/v1/clearing/broker/new", nonce, "R485E04Q","Z4929ZDY",
	    			"ethusd", String.valueOf(random.nextDouble()), 1.0, String.valueOf(random.nextInt()),"sell");
	    	String requestBodyString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(gmbr);
	    	//System.out.println("###### requestBodyString "+requestBodyString);
	    	String encodedPayloadString = Base64.getEncoder().encodeToString(requestBodyString.getBytes());
	    	//System.out.println("###### encodedPayloadString "+encodedPayloadString);
	    	String workingSig = new HmacUtils(HmacAlgorithms.HMAC_SHA_384, api_secret).hmacHex(encodedPayloadString);
	    	//System.out.println("##### working Signature "+workingSig);

	    	HttpHeaders headers = getHttpHeaders(encodedPayloadString, workingSig);

	    	HttpEntity<GeminiNewBrokerorderRequest> requestEntity = new HttpEntity<>(headers);
	    	response = "success";//restTemplate.exchange("https://api.sandbox.gemini.com/v1/clearing/broker/new", HttpMethod.POST, requestEntity, String.class).getBody();
	    	System.out.println("### response "+response);
		} catch (Exception exception) {
			System.out.println("Exception while fetching data from Gemini. Message: "+exception.getMessage());
		}
		return response;
	}
	public boolean isRequestAllowed(String key) {
	    Boolean hasKey = stringRedisTemplate.hasKey(key);
	    if (hasKey) {
	        Long value = hashOperations.increment(key, COUNT, -1l);
	        System.out.println("Current value for key "+key+" is "+value);
	        return value > 0;
	    } else {
	        hashOperations.put(key, COUNT, "600");
	        stringRedisTemplate.expire(key, 1, TimeUnit.MINUTES);
	    }
	    return true;
	}

	private HttpHeaders getHttpHeaders(String encodedPayloadString, String workingSig) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "text/plain");
		headers.add("Content-Length", "0");
		headers.add("X-GEMINI-APIKEY", api_key);
		headers.add("X-GEMINI-PAYLOAD", encodedPayloadString);
		headers.add("X-GEMINI-SIGNATURE", workingSig);
		headers.add("Cache-Control", "no-cache");
		return headers;
	}
}
