package com.gemini.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiApplicationTests {

	@Test
	void contextLoads() {
		/*GeminiService geminiService = new GeminiService();
		for (int i=0; i<700;i++) {
			  String response = geminiService.createNewBroker();
			  System.out.println("### response "+response);
		}*/
	}

}
