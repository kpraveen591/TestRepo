package com.gemini.api;

import java.util.Base64;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import org.apache.commons.codec.digest.HmacAlgorithms;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;

@Component
public class GeminiService {
	
	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	private HashOperations<String, String, String> hashOperations;

	@PostConstruct
	private void init() {
	    hashOperations = stringRedisTemplate.opsForHash();
	}

	private String api_key = "master-tGr3wZzp2plRLJivxuLc";//"account-EP1eYoOzEmWPTPnd4Qrk";
	private String api_secret = "stqEt2ayimJkhwka9Cx6NUqk9SY";//"43SoBBdTE4VSUmFHrAMJwg5cyipw";

	private final String COUNT = "count";

	public String createNewBroker() {

		if (!isRequestAllowed("gemini:"+api_key)) {
			return "Rate Limit Reached. Request not processed.";
		}
		String response = "";
		try {
	    	HttpHeaders headers = getHttpHeaders();
	    	HttpEntity<GeminiNewBrokerorderRequest> requestEntity = new HttpEntity<>(headers);
	    	//response = "success";
	    	response = restTemplate.exchange("https://api.sandbox.gemini.com/v1/clearing/broker/new", HttpMethod.POST, requestEntity, String.class).getBody();
	    	System.out.println("### response "+response);
		} catch (Exception exception) {
			System.out.println("Exception while fetching data from Gemini. Message: "+exception.getMessage());
		}
		return response;
	}

	public String createNewBrokerWithWebClient() throws Exception {

		if (!isRequestAllowed("gemini:"+api_key)) {
			return "Rate Limit Reached. Request not processed.";
		}

		int nonce = Integer.parseInt(String.valueOf(new Date().getTime()).substring(4));
		Random random = new Random(); 
    	GeminiNewBrokerorderRequest gmbr = new GeminiNewBrokerorderRequest("/v1/clearing/broker/new", nonce, "R485E04Q","Z4929ZDY",
    			"ethusd", String.valueOf(random.nextDouble()), 1.0, String.valueOf(Math.abs(random.nextInt())),"sell");
    	String requestBodyString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(gmbr);
    	System.out.println("###### requestBodyString "+requestBodyString);
    	String encodedPayloadString = Base64.getEncoder().encodeToString(requestBodyString.getBytes());
    	String workingSig = new HmacUtils(HmacAlgorithms.HMAC_SHA_384, api_secret).hmacHex(encodedPayloadString);
    	//System.out.println("##### working Signature "+workingSig);

    	String responseString = "";
		WebClient.RequestHeadersSpec<?> headersSpec = WebClient.builder().baseUrl("https://api.sandbox.gemini.com")
				.defaultHeader(HttpHeaders.CACHE_CONTROL, "no-cache")
				.defaultHeader(HttpHeaders.CONTENT_LENGTH, "0")
				.build().post().uri("/v1/clearing/broker/new")
				.bodyValue(BodyInserters.fromValue(""))
				.header("X-GEMINI-APIKEY", api_key)
				.header("X-GEMINI-PAYLOAD", encodedPayloadString)
				.header("X-GEMINI-SIGNATURE", workingSig);
		
		Mono<String> responseMono = headersSpec.exchangeToMono(response -> handleClientResponse(response));
		responseString = responseMono.block();
		return responseString;
	}
	public HttpClient getHttpClient() {
		return HttpClient.create().secure()
				.proxy(proxyOptions -> proxyOptions.type(ProxyProvider.Proxy.HTTP)
						                           .host("proxy.statestr.com")
						                           .port(80)
						                           .build());
	}

	public Mono<String> handleClientResponse(ClientResponse clientResponse) {
		if (clientResponse.statusCode().is2xxSuccessful()) {
			return clientResponse.bodyToMono(String.class);
		} else if (clientResponse.statusCode().is4xxClientError()) {
			return Mono.just(String.format("Error response %s, %s",
					clientResponse.statusCode(), clientResponse.bodyToMono(String.class)));
		} else {
			return clientResponse.createException().flatMap(Mono::error);
		}
	}

	public boolean isRequestAllowed(String key) {
	    Boolean hasKey = stringRedisTemplate.hasKey(key);
	    if (hasKey) {
	        Long value = hashOperations.increment(key, COUNT, -1l);
	        System.out.println("Current value for key "+key+" is "+value);
	        return value > 0;
	    } else {
	        hashOperations.put(key, COUNT, "600");
	        stringRedisTemplate.expire(key, 1, TimeUnit.MINUTES);
	    }
	    return true;
	}

	private HttpHeaders getHttpHeaders() throws Exception {
		int nonce = Integer.parseInt(String.valueOf(new Date().getTime()).substring(3));
		Random random = new Random(); 
    	GeminiNewBrokerorderRequest gmbr = new GeminiNewBrokerorderRequest("/v1/clearing/broker/new", nonce, "R485E04Q","Z4929ZDY",
    			"ethusd", String.valueOf(random.nextDouble()), 1.0, String.valueOf(Math.abs(random.nextInt())),"sell");
    	String requestBodyString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(gmbr);
    	System.out.println("###### requestBodyString "+requestBodyString);
    	String encodedPayloadString = Base64.getEncoder().encodeToString(requestBodyString.getBytes());
    	//System.out.println("###### encodedPayloadString "+encodedPayloadString);
    	String workingSig = new HmacUtils(HmacAlgorithms.HMAC_SHA_384, api_secret).hmacHex(encodedPayloadString);
    	//System.out.println("##### working Signature "+workingSig);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "text/plain");
		headers.add("Content-Length", "0");
		headers.add("X-GEMINI-APIKEY", api_key);
		headers.add("X-GEMINI-PAYLOAD", encodedPayloadString);
		headers.add("X-GEMINI-SIGNATURE", workingSig);
		headers.add("Cache-Control", "no-cache");
		return headers;
	}
}
